user_age = int(input("Enter your age: "))
user_age += 22
print("Now showing the shop items filtered for age:", user_age)