# sample : coding questions: 01 Week 01
#Name : Omar Butt

# Question 2: Defining a array(list)
my_array = [1,4,7,9]
